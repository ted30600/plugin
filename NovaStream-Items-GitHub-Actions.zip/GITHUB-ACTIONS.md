# Compiler NovaStream Items avec GitHub Actions

1. Crée un dépôt GitHub.
2. Envoie tous les fichiers de ce projet dans le dépôt.
3. Ouvre l'onglet **Actions**.
4. Lance **Build NovaStream Items** avec **Run workflow**.
5. Une fois terminé, ouvre le workflow réussi.
6. Dans **Artifacts**, télécharge **NovaStream-Items**.
7. Le fichier `.jar` se trouve dans l'archive téléchargée.

Le workflow utilise Java 21 et Maven.
